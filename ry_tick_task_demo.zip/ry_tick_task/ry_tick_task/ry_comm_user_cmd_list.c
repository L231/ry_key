
#include "ry_comm_uart.h"

#include "cmd_test.h"
#include "cmd_usb.h"
#include "drv_uart.h"







#define  CMD_MSG_TO_SLAVE               0x12
#define  CMD_T_USB                      0x25
#define  CMD_SIN_WAVE                   0x80




/* �û�ָ��ע��� */
const CmdList_t gUserCmdList[] =
{
    
    {CMD_MSG_TO_SLAVE,           drv_cmd_pcmsg_to_slave},
    {CMD_T_USB,                  cmd_usb_task},
    
    {CMD_SIN_WAVE,               cmd_sin_wave},
    
    {RY_NULL,           RY_NULL},
};



