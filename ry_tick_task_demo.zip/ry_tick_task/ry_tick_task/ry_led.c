/*
 * ry_led.c
 *
 *  Created on: 2023年7月30日
 *      Author: 231
 */

#include "ry_led.h"


static ry_led_obj_t __ledObj;
const static uint8_t __ledFlickerCycle[] = {LED_FAST_FLICKER_CYCLE, LED_NORMAL_FLICKER_CYCLE, LED_SLOW_FLICKER_CYCLE};


#define __LED                 __ledObj.list[led]


#define __LED_CTRL(c)         do{\
                                    __LED.ctrl_cbk(c);\
                                    __LED.open = !c;\
                                }while(0)

#define __LED_FLICKER(cycle)  do{\
                                    if(__LED.tick == cycle)\
                                    {\
                                        __LED_CTRL(__LED.open);\
                                        __LED.tick = 0;\
                                    }\
                                }while(0)





/* 创建一个LED，并设置其默认状态 */
void ry_led_create(E_user_led_sn_t led, led_event_t e, void (*ctrl_cbk)(uint8_t))
{
    if(led >= RY_LED_SN_MAX)
        return;
    __LED.event           = e;
    __LED.tick            = 0;
    __LED.encode_num      = 0;
    __LED.encode_cnt      = 0;
    __LED.encode_circular = RY_LED_ENCODE_SINGLE_MODE;
    __LED.init_bits       = 0;
    __LED.remaining_bits  = 0;
    __LED.ctrl_cbk        = ctrl_cbk;
    __LED_CTRL(0);
}


/* 获取LED的事件 */
led_event_t ry_led_event_get(E_user_led_sn_t led)
{
    return __LED.event;
}

/* 配置LED的一般事件 */
void ry_led_event_cfg(E_user_led_sn_t led, led_event_t e)
{
    if(led >= RY_LED_SN_MAX)
        return;
    __LED.event           = e;
    __LED.tick            = 0;
    __LED.encode_circular = RY_LED_ENCODE_SINGLE_MODE;
    __LED.encode_num      = 1;
    __LED.encode_cnt      = 0;
    __LED.init_bits       = RY_LED_ENCODE_BITS_DEFAULT;
    __LED.remaining_bits  = RY_LED_ENCODE_BITS_DEFAULT;
    __LED_CTRL(0);
}


/* 配置LED的循环编码模式 */
void ry_led_encode_circular_cfg(E_user_led_sn_t led, led_event_t *encode, uint8_t encode_num)
{
    if(led >= RY_LED_SN_MAX)
        return;
    __LED.event           = encode[0];
    __LED.tick            = 0;
    __LED.encode          = encode;
    __LED.encode_circular = RY_LED_ENCODE_CIRCULAR_MODE;
    __LED.encode_num      = encode_num;
    __LED.encode_cnt      = 0;
    __LED.init_bits       = RY_LED_ENCODE_BITS_DEFAULT;
    __LED.remaining_bits  = RY_LED_ENCODE_BITS_DEFAULT;
    __LED_CTRL(0);
}


/* 设置LED的编码位数 */
void ry_set_led_encode_bits(E_user_led_sn_t led, uint8_t bits)
{
    if(led >= RY_LED_SN_MAX)
        return;
    if(bits > RY_LED_ENCODE_BITS_MAX)
        bits = RY_LED_ENCODE_BITS_MAX;
    else if(bits == 0)
        bits = 1;
    __LED.init_bits       = bits;
    __LED.remaining_bits  = bits;
}




static void __led_ctrl(E_user_led_sn_t led)
{
    uint8_t OpenStatus;
    ry_led_event_t *LedEvent = (ry_led_event_t *)&__LED.event;
    switch(LedEvent->led_type)
    {
    case RY_LED_BASE_TYPE :
        switch(__LED.event)
        {
        case RY_LED_OFF :
        case RY_LED_ON  :
            __LED_CTRL(LedEvent->e);
            break;
        /* 连续闪烁模式 */
        case RY_LED_FAST_FLICKER   :
        case RY_LED_NORMAL_FLICKER :
        case RY_LED_SLOW_FLICKER   :
            __LED.tick++;
            __LED_FLICKER(__ledFlickerCycle[__LED.event - RY_LED_FAST_FLICKER]);
            break;
        }
        break;
    case RY_LED_ENCODE_TYPE :
        __LED.tick++;
        /* 闪烁周期到了。闪烁周期数组的前两个用作编码，第3个作为空闲时间分隔 */
        if(__LED.tick == __ledFlickerCycle[(LedEvent->e >> __LED.remaining_bits) & 0x1] ||
            __LED.tick == __ledFlickerCycle[2])
        {
            /* 清掉时基 */
            __LED.tick = 0;
            
            OpenStatus = __LED.open;
            /* 还有编码未处理完，翻转LED */
            if(__LED.encode_cnt < __LED.encode_num)
                __LED_CTRL(OpenStatus);
            
            /* 刚刚完成亮灯，则剩余编码位自减 */
            if(OpenStatus)
                __LED.remaining_bits--;
            /* 否则，如果没有剩余编码位，则转移下一个编码 */
            else if(0 == __LED.remaining_bits)
            {
                /* 循环编码模式 */
                if(__LED.encode_circular)
                {
                    /* 下个周期需要关灯，即与下个编码大周期隔开一段时间 */
                    __LED.open = 0;
                    __LED.remaining_bits = __LED.init_bits;
                    __LED.tick           = __ledFlickerCycle[1];
                    
                    __LED.encode_cnt++;
                    /* 一串编码的大周期已结束，偏移归0 */
                    if(__LED.encode_cnt > __LED.encode_num)
                        __LED.encode_cnt     = 0;
                    __LED.event = __LED.encode[__LED.encode_cnt];
                    
                    /* 已输出一串编码，现在输出一段空闲时间，作为间隔 */
                    if(__LED.encode_cnt == __LED.encode_num)
                    {
                        __LED.event          = RY_LED_ENCODE0;
                        __LED.remaining_bits = 0;
                    }
                }
                /* 单次编码模式，需要关闭LED，退出编码 */
                else
                    __LED.event = RY_LED_OFF;
            }
        }
        break;
    }
}


/* LED扫描，定时调用该函数实现LED控制 */
void ry_led_scan(void)
{
    E_user_led_sn_t sn;
    for(sn = (E_user_led_sn_t)0; sn < RY_LED_SN_MAX; sn++)
    {
        __led_ctrl((E_user_led_sn_t)sn);
    }
}




