/*
 * ry_led.h
 *
 *  Created on: 2023年7月30日
 *      Author: 231
 */

#ifndef __DRV_UART_H__
#define __DRV_UART_H__

#include "ry_comm_uart.h"
#include "user_conf.h"



extern void    drv_uart_init(void);
extern uint8_t drv_cmd_pcmsg_to_slave(Msg_t *msg);
extern void    drv_printf(const char * fmt, ...);


#if DBG_PRINTF_ENABLE == 1
#define DBG_LOG            drv_printf
#else
#define DBG_LOG(...)
#endif



#endif /* __DRV_UART_H__ */
