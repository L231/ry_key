
#include "drv_uart.h"
#include "drv_key.h"
#include "bsp_io.h"







extern void bsp_systick_cfg(void);
extern void bsp_usb_reg(void);
extern void drv_led_create(void);


void ry_board_init(void)
{
    bsp_systick_cfg();
    bsp_usb_reg();
    bsp_io_init();
    drv_uart_init();
    drv_key_create();
    drv_led_create();
}


