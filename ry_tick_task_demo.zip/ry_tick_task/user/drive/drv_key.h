/*
 * ry_led.h
 *
 *  Created on: 2023年7月30日
 *      Author: 231
 */

#ifndef __DRV_KEY_H__
#define __DRV_KEY_H__

#include "ry_key.h"





/* 用户注册的按键枚举 */
typedef enum
{
    /* 独立按键 */
    KEY_POWER,
    KEY_CTRL,
    KEY_MAX,
    
    /* 自定义的组合键 */
    KEY_COMPOUND1  = 0,
    KEY_COMPOUND_MAX
}E_drv_user_key_t;




/* 创建按键，暂时先不注册事件处理，由应用层注册 */
extern void drv_key_create(void);
extern void drv_set_key_event_handler(uint8_t key, uint8_t event, callback cbk);
extern void drv_set_key_compound_event_handler(uint8_t key, callback cbk);





#endif /* RY_UART_H_ */
