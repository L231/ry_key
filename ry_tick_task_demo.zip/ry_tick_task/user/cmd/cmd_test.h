#ifndef __CMD_TEST_H__
#define	__CMD_TEST_H__



#include "ry_comm_uart.h"

extern uint8_t cmd_sin_wave(Msg_t *msg);




#endif
