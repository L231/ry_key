#ifndef __BSP_IO_H__
	#define	__BSP_IO_H__

#include <stdint.h>


#define LED1_CLK                  RCC_APB2Periph_GPIOB
#define LED1_PORT                 GPIOB
#define LED1_PIN                  GPIO_Pin_5


#define KEY1_CLK                  RCC_APB2Periph_GPIOE
#define KEY1_PORT                 GPIOE
#define KEY1_PIN                  GPIO_Pin_3

#define KEY2_CLK                  RCC_APB2Periph_GPIOE
#define KEY2_PORT                 GPIOE
#define KEY2_PIN                  GPIO_Pin_4






extern void    bsp_io_init(void);
extern uint8_t bsp_get_key1_level(void);
extern uint8_t bsp_get_key2_level(void);
/* �͵�ƽ���� */
extern void    bsp_led_ctrl(uint8_t status);





#endif
