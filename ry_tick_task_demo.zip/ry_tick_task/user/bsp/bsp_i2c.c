
#include "stdarg.h"
#include "string.h"
#include "stdio.h"


#if 0


#define  I2C_ADDR                  (0xAA)

/*�ȴ���ʱʱ��*/
#define  I2CT_FLAG_TIMEOUT         ((uint32_t)0x1000)
#define  I2CT_LONG_TIMEOUT         ((uint32_t)(10 * I2CT_FLAG_TIMEOUT))



static void __i2c_nvic_cfg(void)
{
	NVIC_InitTypeDef  NVIC_InitStructure;
	
	NVIC_InitStructure.NVIC_IRQChannel                   = I2C1_EV_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

void bsp_i2c_init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	I2C_InitTypeDef   I2C_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_OD;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	__i2c_nvic_cfg();
	
	I2C_InitStructure.I2C_ClockSpeed          = 100000;
	I2C_InitStructure.I2C_Mode                = I2C_Mode_I2C;
	I2C_InitStructure.I2C_DutyCycle           = I2C_DutyCycle_16_9;
	I2C_InitStructure.I2C_OwnAddress1         = I2C_ADDR;
	I2C_InitStructure.I2C_Ack                 = I2C_Ack_Enable;
	I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
	I2C_Init(I2C1, &I2C_InitStructure);
	
	I2C_Cmd(I2C1, ENABLE);
	I2C_ITConfig(I2C1, I2C_IT_BUF | I2C_IT_EVT, ENABLE);
}


/**
 * ������I2C��ʱ����
 **/
static uint8_t __i2c_over_timer_handle(uint8_t err)
{
//	TP_PC_Printf("I2C��ʱ��err = %d!", err);
	return 0;
}

/**
 * ������I2C�����ַ������Զ��л����ӻ�����ʵ������uart�İ�˫��ͨ��
 **/
uint8_t bsp_i2c_string_send(char *p_buf)
{
	uint32_t over_time = I2CT_FLAG_TIMEOUT;
	
	/* ���жϣ�����I2C����״̬ */
	I2C1->CR2 &= ~(I2C_CR2_ITBUFEN | I2C_CR2_ITEVTEN);
	
	while(I2C_GetFlagStatus(I2C1, I2C_FLAG_BUSY))
	{
		if(over_time-- == 0)
            return __i2c_over_timer_handle(4);
	}
	
	I2C_GenerateSTART(I2C1, ENABLE);
	over_time = I2CT_FLAG_TIMEOUT;
	while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT))
	{
		if(over_time-- == 0)
            return __i2c_over_timer_handle(5);
	}
	
	I2C_Send7bitAddress(I2C1, I2C_ADDR, I2C_Direction_Transmitter);
	over_time = I2CT_FLAG_TIMEOUT;
	while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED))
	{
		if(over_time-- == 0)
            return __i2c_over_timer_handle(6);
	}
	
	while(*p_buf != '\0')
	{
		I2C_SendData(I2C1, *p_buf++);
		over_time = I2CT_FLAG_TIMEOUT;
		while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_TRANSMITTED))
		{
			if(over_time-- == 0)
                return __i2c_over_timer_handle(8);
		}
	}
	
	I2C_GenerateSTOP(I2C1, ENABLE);
	
	/* ���жϣ�����I2C�ӻ�״̬ */
	I2C1->CR2 |= I2C_CR2_ITBUFEN | I2C_CR2_ITEVTEN;
	return 0;
}



//#ifdef COMM_I2C
void I2C1_EV_IRQHandler(void)
{
	static uint8_t sRecDataCount = 0;
	char data;
	if(I2C_GetFlagStatus(I2C1, I2C_FLAG_MSL) == RESET) //���Ǵӻ�
	{
		if(I2C_GetFlagStatus(I2C1, I2C_FLAG_ADDR) == SET)  //��ַ
		{
			sRecDataCount = 0;
		}
		if(I2C_GetFlagStatus(I2C1, I2C_FLAG_RXNE))  //��DR
		{
			data = I2C_ReceiveData(I2C1);
			gToMaster.RecBuf[sRecDataCount++]   = data;
			if(data == '\r')
			{
				gToMaster.RecBuf[--sRecDataCount] = '\0';
				gToMaster.RecComplete             = SET;
				sRecDataCount                     = 0;
			}
		}
		if(I2C_GetFlagStatus(I2C1, I2C_FLAG_STOPF))  //ֹͣ�ź�
		{
			
		}
	}
}
//#endif


#endif










