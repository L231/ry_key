
#include "stm32f10x.h"

#include "user_conf.h"




static uint32_t __Tick = 0;


void bsp_systick_cfg(void)
{
    RCC_ClocksTypeDef  mcu_clk;
    RCC_GetClocksFreq(&mcu_clk);
    SysTick_Config(mcu_clk.SYSCLK_Frequency / 1000000 * RY_TICK_PERIOD);
}


/* ��ȡ��ǰϵͳʱ�� */
uint32_t ry_get_systick(void)
{
    return __Tick;
}





void SysTick_Handler(void)
{
    __Tick++;
}




