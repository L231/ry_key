
#include "stm32f10x.h"
#include "bsp_io.h"





void bsp_io_init(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
    
    RCC_APB2PeriphClockCmd(LED1_CLK | KEY1_CLK | KEY2_CLK, ENABLE);
    
    /* LED */
    GPIO_InitStructure.GPIO_Pin   = LED1_PIN;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
    GPIO_Init(LED1_PORT, &GPIO_InitStructure);
    
    /* �������� */
    GPIO_InitStructure.GPIO_Pin  = KEY1_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(KEY1_PORT, &GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin  = KEY2_PIN;
    GPIO_Init(KEY2_PORT, &GPIO_InitStructure);
}


uint8_t bsp_get_key1_level(void)
{
    return GPIO_ReadInputDataBit(KEY1_PORT, KEY1_PIN);
}

uint8_t bsp_get_key2_level(void)
{
    return GPIO_ReadInputDataBit(KEY2_PORT, KEY2_PIN);
}

/* �͵�ƽ���� */
void bsp_led_ctrl(uint8_t status)
{
    if(status)
        GPIO_ResetBits(LED1_PORT, LED1_PIN);
    else
        GPIO_SetBits(LED1_PORT, LED1_PIN);
}

