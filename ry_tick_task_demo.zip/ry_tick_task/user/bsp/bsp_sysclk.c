
#include "stm32f10x.h"





void bsp_hse_set_sys_clk(uint32_t pllmul)
{
    __IO uint32_t StartUpCounter = 0, HSEStartUpStatus = 0;
    
    RCC_DeInit();
    RCC_HSEConfig(RCC_HSE_ON);
    HSEStartUpStatus = RCC_WaitForHSEStartUp();
    
    // 只有 HSE 稳定之后则继续往下执行
    if (HSEStartUpStatus == SUCCESS)
    {
        FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);
        
        // 0：0 < SYSCLK <= 24M
        // 1：24< SYSCLK <= 48M
        // 2：48< SYSCLK <= 72M
        FLASH_SetLatency(FLASH_Latency_2);
        
        // AHB预分频因子设置为1分频，HCLK = SYSCLK 
        RCC_HCLKConfig(RCC_SYSCLK_Div1); 
  
        // APB2预分频因子设置为1分频，PCLK2 = HCLK
        RCC_PCLK2Config(RCC_HCLK_Div1); 

        // APB1预分频因子设置为1分频，PCLK1 = HCLK/2 
        RCC_PCLK1Config(RCC_HCLK_Div2);
        
        // 设置PLL时钟来源为HSE，设置PLL倍频因子
        RCC_PLLConfig(RCC_PLLSource_HSE_Div1, pllmul);
        RCC_PLLCmd(ENABLE);
        while (RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET);
        RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

        // 读取时钟切换状态位，确保PLLCLK被选为系统时钟
        while (RCC_GetSYSCLKSource() != 0x08);
    }
    else
    {
        while(1);
    }
}





