/******************************************************************************
���ڣ�
�汾��V2.0
���ߣ�231
˵����
���䣺
******************************************************************************/

#include "ry_task.h"
#include "drv_uart.h"

#include "ry_cal.h"





extern void key_event_init(void);


/**
 * ����ͨ�Žӿڣ�
 *
 *            +--- PA9 ---+
 *     MCU ---+           +------ PC
 *            +--- PA10 --+
 *
 *
 **/
int main(void)
{
    ry_task_init();
    key_event_init();
    DBG_LOG("system run\r\n");
#if 0
    {
        float ovp, pack1, pack2;
        uint32_t cc1, cc1Base;
        cc1     = ry_get_original(DAC_CalTable,      CH_SET_CC1_10A, 1000);
        cc1Base = ry_get_basic_original(DAC_CalTable,CH_SET_CC1_10A, 1000);
        ovp     = ry_get_actual(ADC_CalTable, CH_VOLT_ADC_OVP, 450);
        pack1   = ry_get_actual(ADC_CalTable, CH_VOLT_ADC_PACK, 1643);
        pack2   = ry_get_actual(ADC_CalTable, CH_VOLT_ADC_PACK, 5267);
        
        tp_printf("cc1     = %d\r\n", cc1);
        tp_printf("cc1Base = %d\r\n", cc1Base);
        tp_printf("ovp     = %f\r\n", ovp);
        tp_printf("pack1   = %f\r\n", pack1);
        tp_printf("pack2   = %f\r\n", pack2);
    }
#endif
    while(1)
    {
        ry_task_run();
    }
}


