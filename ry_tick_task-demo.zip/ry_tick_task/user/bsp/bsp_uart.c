
#include <stdarg.h>
#include <string.h>
#include <stdio.h>

#include "stm32f10x.h"
#include "bsp_uart.h"




void (*uart_rx_callback)(uint8_t) = 0;



void bsp_uart_init(uint32_t baud_rate)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef  NVIC_InitStructure;

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    
    USARTx_CLK_CMD();
    TX_GPIO_CLK_CMD();
    RX_GPIO_CLK_CMD();
    
    NVIC_InitStructure.NVIC_IRQChannel                   = USARTx_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin   = TX_PIN;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_Init(TX_GPIO, &GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin  = RX_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(RX_GPIO, &GPIO_InitStructure);
    
    USART_InitStructure.USART_BaudRate            = baud_rate;
    USART_InitStructure.USART_WordLength          = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits            = USART_StopBits_1;
    USART_InitStructure.USART_Parity              = USART_Parity_No;
    USART_InitStructure.USART_Mode                = USART_Mode_Tx | USART_Mode_Rx;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_Init(USARTx, &USART_InitStructure);
    USART_ITConfig(USARTx, USART_IT_RXNE, ENABLE);
    USART_Cmd(USARTx, ENABLE);
}



void bsp_reg_uart_rx_callback(void (*rx_cbk)(uint8_t))
{
    uart_rx_callback = rx_cbk;
}




static void __put_char(uint8_t c)
{
    while(USART_GetFlagStatus(USARTx, USART_FLAG_TXE) == RESET);
    USART_SendData(USARTx, c);
}


void bsp_usart_send(uint8_t *buff, uint16_t len)
{
    while(len--)
    {
        __put_char(*buff++);
    }
    while(USART_GetFlagStatus(USARTx, USART_FLAG_TC) == RESET);
}






void USARTx_IRQHandler(void)
{
    char data;
    if(USART_GetITStatus(USARTx, USART_IT_RXNE) == SET)
    {
        data = USART_ReceiveData(USARTx);
        if(uart_rx_callback)
            uart_rx_callback(data);
#if DEBUG_UART_RX_ECHO == 1
        __put_char(data);  //����
#endif
    }
}

