#ifndef __BSP_IO_H__
	#define	__BSP_IO_H__

#include <stdint.h>


#define LED1_CLK                  RCC_APB2Periph_GPIOA
#define LED1_PORT                 GPIOA
#define LED1_PIN                  GPIO_Pin_0


#define KEY1_CLK                  RCC_APB2Periph_GPIOA
#define KEY1_PORT                 GPIOA
#define KEY1_PIN                  GPIO_Pin_1

#define KEY2_CLK                  RCC_APB2Periph_GPIOA
#define KEY2_PORT                 GPIOA
#define KEY2_PIN                  GPIO_Pin_2






extern void    bsp_io_init(void);
extern uint8_t bsp_get_key1_level(void);
extern uint8_t bsp_get_key2_level(void);
/* �͵�ƽ���� */
extern void    bsp_led_ctrl(uint8_t status);





#endif
