
#include "cmd_usb.h"
#include "drv_uart.h"

#include "hw_config.h"
#include "usb_lib.h"




/* ָ����ʾ����ʱ��ʵ������ */
uint8_t cmd_usb_task(Msg_t *msg)
{
    msg->len = 0;
    switch(msg->buf[1])
    {
        case 0 :
            DBG_LOG("#ERR_NO\r\n");
            break;
        case 1 :
            DBG_LOG("#ERR_POS_FAIL\r\n");
            break;
        case 2 :
            DBG_LOG("#ERR_POS_WARN\r\n");
            break;
    }
//	Joystick_Send(msg->buf[1]);
//	if(0 == msg->buf[1])
//		ry_task_standby(&gTusb);
//	else
//		ry_task_recover(&gTusb, RY_TASK_READY);
	return COMMAND_RUN_OK;
}

