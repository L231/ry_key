#ifndef __CMD_USB_H__
#define	__CMD_USB_H__



#include "ry_comm_uart.h"

extern uint8_t cmd_usb_task(Msg_t *msg);




#endif
