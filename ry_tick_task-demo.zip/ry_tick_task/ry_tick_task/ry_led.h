/*
 * ry_led.h
 *
 *  Created on: 2023年7月30日
 *      Author: 231
 */

#ifndef RY_TICK_TASK_RY_LED_H_
#define RY_TICK_TASK_RY_LED_H_

#include <stdint.h>



/* 编码扩展模式，更多的bit，更长的字符串 */
#define RY_LED_ENCODE_EXPAND              0

/* LED扫描周期(建议50ms)，用户自行调整 */
#define LED_SCAN_CYCLE                   (50)
/* LED的 3档闪烁周期，自行配置 */
#define LED_FAST_FLICKER_CYCLE           (uint8_t)(150  / LED_SCAN_CYCLE)
#define LED_NORMAL_FLICKER_CYCLE         (uint8_t)(600  / LED_SCAN_CYCLE)
#define LED_SLOW_FLICKER_CYCLE           (uint8_t)(2000 / LED_SCAN_CYCLE)


/* 自行注册LED，如下注册了一个“LED_USER” */
typedef enum
{
    LED_USER,
    
    RY_LED_SN_MAX,
}E_user_led_sn_t;






#if RY_LED_ENCODE_EXPAND == 1
/* 扩展成15bit编码 */
typedef uint16_t     led_event_t;
#define LED_BITS_MAX                      15
#else
/* 默认7bit编码 */
typedef uint8_t      led_event_t;
#define LED_BITS_MAX                      7
#endif

/* 编码的位数，MSB。LED支持输出 如7bit的ASCII */
#define RY_LED_ENCODE_BITS_MAX            LED_BITS_MAX
/* 默认编码位数 */
#define RY_LED_ENCODE_BITS_DEFAULT        RY_LED_ENCODE_BITS_MAX



/* 循环编码模式 */
typedef enum
{
    RY_LED_ENCODE_SINGLE_MODE,    /* 单次模式 */
    RY_LED_ENCODE_CIRCULAR_MODE,  /* 循环模式 */
}E_led_encode_t;


/* LED的事件 */
typedef enum
{
    RY_LED_TYPE_OFFSET          = RY_LED_ENCODE_BITS_MAX,
    RY_LED_ENCODE_TYPE          = 0,
    RY_LED_BASE_TYPE            = 1,
    
    /* 常规的事件 */
    RY_LED_OFF                  = RY_LED_BASE_TYPE << RY_LED_TYPE_OFFSET,
    RY_LED_ON,
    RY_LED_FAST_FLICKER,
    RY_LED_NORMAL_FLICKER,
    RY_LED_SLOW_FLICKER,
    
    /* 以字符编码形式闪烁LED */
    RY_LED_ENCODE0              = RY_LED_ENCODE_TYPE << RY_LED_TYPE_OFFSET,
    RY_LED_ENCODE1,
    RY_LED_ENCODE2,
    RY_LED_ENCODE3,
    RY_LED_ENCODE4,
    RY_LED_ENCODE5,
    RY_LED_ENCODE6,
    RY_LED_ENCODE7,
    RY_LED_ENCODE8,
    RY_LED_ENCODE9,
    RY_LED_ENCODE10,
    RY_LED_ENCODE11,
    RY_LED_ENCODE12,
    RY_LED_ENCODE13,
    RY_LED_ENCODE14,
    RY_LED_ENCODE15,
}E_led_event_t;



typedef struct
{
    led_event_t    e        : LED_BITS_MAX; /* 具体的事件码 */
    led_event_t    led_type : 1;            /* 事件的类型 */
}ry_led_event_t;


typedef struct
{
    led_event_t  *encode;               /* 指向编码数组 */
#if RY_LED_ENCODE_EXPAND == 1
    uint8_t       encode_num;           /* 总的编码数 */
    uint8_t       encode_cnt;           /* 编码已处理的计数器 */
    uint8_t       init_bits       : 4;  /* 编码的位数 */
    uint8_t       remaining_bits  : 4;  /* 当前未处理的位数 */
#else
    uint8_t       encode_num      : 4;
    uint8_t       encode_cnt      : 4;
    uint8_t       init_bits       : 3;
    uint8_t       remaining_bits  : 3;
#endif
    uint8_t       encode_circular : 1;  /* 编码是否循环处理 */
    uint8_t       open            : 1;  /* 开关控制 */
    uint8_t       tick;                 /* 时基 */
    led_event_t   event;                /* LED的事件 */
    void        (*ctrl_cbk)(uint8_t);   /* LED亮灭回调函数 */
}ry_led_t;


/* LED控制块，管理所有注册的LED */
typedef struct
{
    ry_led_t      list[RY_LED_SN_MAX]; /* LED列表 */
}ry_led_obj_t;





/* 创建一个LED，并设置其默认状态 */
extern void ry_led_create(E_user_led_sn_t led, led_event_t e, void (*ctrl_cbk)(uint8_t));
/* 获取LED的事件 */
extern led_event_t ry_led_event_get(E_user_led_sn_t led);
/* 配置LED的一般事件 */
extern void ry_led_event_cfg(E_user_led_sn_t led, led_event_t e);
/* 配置LED的循环编码模式 */
extern void ry_led_encode_circular_cfg(E_user_led_sn_t led, led_event_t *encode, uint8_t encode_num);
/* 设置LED的编码位数 */
extern void ry_set_led_encode_bits(E_user_led_sn_t led, uint8_t bits);
/* LED扫描，定时调用该函数实现LED控制 */
extern void ry_led_scan(void);




#endif /* RY_TICK_TASK_RY_LED_H_ */
